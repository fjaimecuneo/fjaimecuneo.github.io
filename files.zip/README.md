# Personal Research Site — Francisco Jaime Cuneo

A minimalist, editorial-style personal site for publishing analytical notes
on markets, geopolitics, and investment work. Pure HTML + CSS + a few lines
of JavaScript. No build step, no framework, no dependencies.

---

## Project structure

```
site/
├── index.html              ← Home (hero + featured articles)
├── articles.html           ← Articles index / listing
├── about.html              ← Bio + skills
├── contact.html            ← Email + copy button
│
├── articles/
│   ├── hormuz-premium.html         ← Sample article 1 (geopolitics)
│   ├── quality-late-cycle.html     ← Sample article 2 (markets)
│   └── sotp-latam-holding.html     ← Sample article 3 (valuation)
│
├── css/
│   └── styles.css          ← All styling. Design tokens at the top.
│
├── js/
│   └── main.js             ← Mobile menu, copy-email button, footer year
│
└── README.md               ← This file.
```

---

## How to run it locally

You have two options. Both work — pick whichever is easier.

### Option A — Just open the file (simplest)

Double-click `index.html`. It will open in your default browser. That's it.

> Note: with this method, links between pages still work, but some browsers
> are stricter about local files (e.g. fonts may not load on Safari). The
> next option is more reliable.

### Option B — Run a tiny local server (recommended)

If you have **Python** installed (most Macs and Linux machines do):

```bash
cd path/to/site
python3 -m http.server 8000
```

Then open: `http://localhost:8000`

If you have **Node.js** installed:

```bash
cd path/to/site
npx serve
```

Then open the URL it prints (usually `http://localhost:3000`).

---

## How to publish it on the internet

This is a static site, so deployment is essentially free and takes minutes:

- **Netlify** — drag the `site/` folder onto netlify.com/drop. Done.
- **Vercel** — `vercel deploy` from the folder, or connect a GitHub repo.
- **GitHub Pages** — push to a repo, enable Pages in settings.
- **Cloudflare Pages** — connect a repo, no config needed.

All four are free for personal sites.

---

## How to edit content

### Change your name, email, or links across the site

Each HTML file has its own header and footer (kept inline so there are no
build steps). To change site-wide elements:

1. Update the `<a class="brand">` block inside the `<header>` of each page.
2. Update the email in `contact.html` — both the `mailto:` link and the
   `data-email` attribute on the copy button.
3. Update the footer copyright line if needed.

> Tip: keep these in sync. If this becomes annoying, the next step is a
> static-site generator (Astro, Eleventy, Hugo) — but for ~5 pages, plain
> HTML is faster.

### Change the colors, fonts, or spacing

Open `css/styles.css`. The first ~40 lines are CSS variables — change them
once and the whole site updates:

```css
:root {
  --bg:    #F7F5EF;   /* page background */
  --ink:   #14181C;   /* primary text */
  --accent:#1B2845;   /* navy — links, emphasis */
  /* ... */
}
```

To swap fonts:
1. Pick new fonts on [Google Fonts](https://fonts.google.com).
2. Update the `<link>` tag at the top of each HTML file.
3. Update `--display`, `--sans`, `--mono` in `:root` in `styles.css`.

---

## How to add a new article

It's three steps.

### 1. Copy an existing article file

Inside `articles/`, copy `hormuz-premium.html` and rename it to your slug,
e.g. `articles/em-fx-thesis.html`. Use lowercase, hyphens, no spaces.

### 2. Edit the new file

Update these things in your new article file:

- `<title>` — the browser tab title
- `<meta name="description">` — for SEO and social previews
- The `meta-row` (category, date, read time) inside `<header class="article-header">`
- The `<h1>` headline
- The `<p class="deck">` deck/subhead
- The body copy inside `<article class="prose">`
- The "Vol. III · No. XX" reference in the article footer (optional)

The body supports:
- `<h2>` and `<h3>` for sections
- `<p>` for paragraphs
- `<ul>` / `<ol>` for lists
- `<blockquote>` for pull quotes
- `<div class="callout">` for highlighted thesis / takeaway boxes
  (see the sample articles for the structure)

### 3. Add it to the listings

Open `articles.html` and **add a new `<li class="article-card">` block at
the top of the `<ul class="articles-list">`**. There's a commented-out
template inside that file you can copy.

If you want the article to also appear on the homepage, do the same thing
in `index.html` (and remove the bottom-most card so you keep three featured).

That's it — refresh the browser.

---

## Conventions used

- **Numbering** (`N° 01`, `N° 02`, etc.) — increments oldest-to-newest. You
  can reverse the convention if you prefer; it's purely cosmetic.
- **Dates** — written in `DD MMM YYYY` format (e.g. `22 Apr 2026`). Pick a
  format and stick to it.
- **Categories** — short, two-word labels separated by a middle dot
  (e.g. `Markets · Strategy`). Keeps the visual hierarchy clean.

---

## Browser support

Tested on modern Chrome, Safari, Firefox, and Edge. Mobile-responsive
breakpoints at 720px (nav) and 640px (typography). No IE support — no one
should be writing for IE in 2026.

---

## License / attribution

Content is yours. Code is yours to modify freely. Fonts are loaded from
Google Fonts under the SIL Open Font License.
